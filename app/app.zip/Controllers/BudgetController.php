<?php
namespace App\Controllers;
use App\Models\BudgetModel;

class BudgetController extends BaseController
{
    //Obtenir tous les budgets
    function index()
    {
        $db = \Config\Database::connect();
        $query = $db->query("SELECT users_table.name,users_table.surname,Budgets_table.created_at,Budgets_table.budget_ga,Budgets_table.budget_sn
        , Budgets_table.budget_id,users_table.id 
FROM budgets_table,users_table
where Budgets_table.user_id = users_table.id order by budget_id");
        $data['app_name'] = "QUICK TRANSFER";
        $data['budget_data'] = $query->getResultArray();
        $data['page_title'] = 'Gestion des budgets';
        return view('budget/index', $data);
    }

    // Appéller la page édit budget
    public function edit($budget_id)
    {
        $BudgetModel = new BudgetModel();
        $data['budget_data'] = $BudgetModel->find($budget_id);
        $data['page_title'] = 'Gestion des budgets';
        return view('budget/edit', $data);
    }

    // update product data
    public function update($budget_id)
    {
        $BudgetModel = new BudgetModel();
        $data = [
            'user_id' => $this->request->getPost('user_id'),
            'budget_ga'  => $this->request->getPost('budget_ga'),
            'budget_sn'  => $this->request->getPost('budget_sn')
        ];
         $save = $BudgetModel->update($budget_id, $data);
        $session = session();
        $session->setFlashdata('success', 'Super! Vous avez réussi à mettre à jour les budgets!');
       
        return redirect()->to('/budgets');
    }
}
