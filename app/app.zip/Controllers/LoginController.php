<?php
namespace App\Controllers;
use App\Models\UserModel;
use App\Models\BudgetModel;
use App\Models\OperationModel;
$session = session();


class LoginController extends BaseController
{
    public function index(): string
    {
        return view('login');
    }

    //Connexion
   
    public function login()
    {
        $session = session();
        $UserModel = new UserModel();
        $user_email = $this->request->getVar('user_email');
        $user_password = $this->request->getVar('user_password');
        $data = $UserModel->where('email', $user_email)->first();
        
        if ($data) {
            $pass = $data['password'];
            //$verify_pass = password_verify($password, $pass);
            if ($user_password==$pass) {
                $users_data = [
                    'id'       => $data['id'],
                    'surname' => $data['surname'],
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'logged_in'     => TRUE
                ];

                $session->set($users_data);
                return redirect()->to('/dashbord');
            } else {
                $session->setFlashdata('msg', 'Mauvais mot de passe');
                return redirect()->to('/');
            }
        } else {
            $session->setFlashdata('msg', 'Email incorrecte');
            return redirect()->to('/');
        }
    }

    public function dashbord(): string
    {
          $BudgetModel = new BudgetModel();
        $OperationModel = new OperationModel();
         $db = \Config\Database::connect();
         
         $data['line_chart'] = $OperationModel->getChartLine();

         $data['bar_chart'] = $OperationModel->getChartBar();

         $data['camember_data'] = $OperationModel->getChartCamember();

// Reccupère envois
 $query = $db->query("SELECT *
FROM operations_table
ORDER BY operation_id DESC LIMIT 3");
$data['operation_data'] = $query->getResultArray();




         //RECUPERE SUPPLY
        $query = $db->query("SELECT supply_table.created_at,supply_table.supply_id,
         supply_table.amount,supply_table.tel_receiver,supply_table.name_receiver
,users_table.name,users_table.surname,users_table.id 
FROM supply_table,users_table
where supply_table.user_id = users_table.id order by supply_id desc limit 5");

$data['supply_data'] = $query->getResultArray();
      
        // Total profit
       $builder = $db->query('Select sum(profit) as profit_data from operations_table');
       $results = $builder->getRow();
       $data['profittop'] = $results->profit_data ?? 0;

    // Total envois SN
       $builder = $db->query('Select sum(amount) as ts_data from supply_table');
       $results = $builder->getRow();
       $data['ts_data'] = $results->ts_data ?? 0;

       // Total envois GA
       $builder = $db->query('Select sum(total_sent) as ga_data from operations_table');
       $results = $builder->getRow();
       $data['tg_data'] = $results->ga_data ?? 0;

 
 
       //Solde senegal
       $builder = $db->query('Select budget_sn as liq_sn from budgets_table order by budget_id desc limit 1');
       $results = $builder->getRow();
       $data['liq_sn'] = $results->liq_sn ?? 0;

       //Solde gabon
       $builder = $db->query('Select budget_ga as liq_ga from budgets_table order by budget_id desc limit 1');
       $results = $builder->getRow();
       $data['liq_ga'] = $results->liq_ga ?? 0;

        //Solde total
       $builder = $db->query('Select (budget_ga + budget_sn) as liq_total from budgets_table ORDER by budget_id desc LIMIT 1');
       $results = $builder->getRow();
       $data['liq_total'] = $results->liq_total ?? 0;

        //Revenus actuel
       $builder = $db->query('SELECT sum(profit) as profit_total_now FROM operations_table
WHERE month(created_at) = month(CURRENT_DATE)
AND year(created_at)=year(created_at)');
       $results = $builder->getRow();
       $data['profit_total_now'] = $results->profit_total_now ?? 0;

        //Revenus month-1
       $builder = $db->query('SELECT sum(profit) as profit_total_1 FROM operations_table
WHERE month(created_at)=month(CURRENT_DATE)-1
AND year(created_at)=year(created_at)');
       $results = $builder->getRow();
       $data['profit_total_1'] = $results->profit_total_1 ?? 0;

       

        $data['app_name']="QUICK TRANSFER";
        $data['page_title']="Dashboard";


       return view('dashbord', $data);
    }

    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/');
    }

  
}

