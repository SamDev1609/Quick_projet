<?php

namespace App\Controllers;

use App\Models\OperationModel;
use App\Models\BudgetModel;
use \Config\Services\session;

class OperationController extends BaseController
{

    public function create(): string
    {
        $data['page_title'] = 'Gestion des transferts';
        return view('operation/create', $data);
    }



    //Get all sends
    function index()
    {
        $db = \Config\Database::connect();
        $query = $db->query("SELECT operations_table.created_at,operations_table.operation_id,
         operations_table.amount,operations_table.profit,operations_table.lost
        ,users_table.name,users_table.surname 
        FROM operations_table,users_table
        where operations_table.user_id = users_table.id order by operation_id desc");
        $data['operations_data'] = $query->getResultArray();
        $data['page_title'] = "Gestion des transferts";
        return view('operation/index', $data);
    }

    // Save new send
    public function save()
    {
        $send = new OperationModel();
        $budget = new BudgetModel();
        $db = \Config\Database::connect();

        if ($this->request->getPost('amount1')) {
             //Recup variables
        $profit = $this->request->getPost('amount1')*0.09- $this->request->getPost('lost');
        $amount = $this->request->getPost('amount1');
        $lost = $this->request->getPost('lost');
        $total_sent = $this->request->getPost('amount1') +  $this->request->getPost('lost');
        $user_id = $this->request->getPost('user_id');

        // Recup les budgets
            $query1 = $db->query("SELECT budget_id,budget_ga,budget_sn FROM budgets_table
            ORDER BY budget_id DESC
            LIMIT 1");
            $row1 = $query1->getRow();

            // Retirer le total sent du budget Senegal 
            $new_budget_sn = $row1->budget_sn - $total_sent;

            // Ajouter le total sent au budget
            $new_budget_ga = $row1->budget_ga + $amount+$profit;

            // Inserer les nouveaux budgets 
            $budget->insert([
                'budget_ga' =>  $new_budget_ga,
                'budget_sn' =>  $new_budget_sn,
                'user_id' => $user_id
            ]);

            // Inserer les données de l'operation 
            $send->insert([
                'user_id' => $this->request->getPost('user_id'),
                'amount' =>  $amount,
                'profit' =>  $profit,
                'lost' => $lost,
                'total_sent' => $total_sent
            ]);

            $session = session();
            $session->setFlashdata('success', 'Envoi sauvegardé avec succès!');
            return redirect()->to('/operations');
           
        } else {

        //Recup variables
        $lost = $this->request->getPost('lost');
        $profit = $this->request->getPost('amount2') * 0.09 - $lost ;
        $total_sent = $this->request->getPost('total_sent');
        $user_id = $this->request->getPost('user_id');
        $amount = $this->request->getPost('amount2') - $profit - $lost;

        // Recup les budgets
            $query1 = $db->query("SELECT budget_id,budget_ga,budget_sn FROM budgets_table
            ORDER BY budget_id DESC
            LIMIT 1");
            $row1 = $query1->getRow();

        // Retirer le total sent du budget Senegal 
            $new_budget_sn = $row1->budget_sn - $total_sent;

            // Ajouter le total sent au budget
            $new_budget_ga = $row1->budget_ga + $amount;

         // Inserer les nouveaux budgets 
            $budget->insert([
                'budget_ga' => $new_budget_ga,
                'budget_sn' => $new_budget_sn,
                'user_id' => $user_id
            ]);

            // Inserer les données de l'operation 
            $send->insert([
                'user_id' => $this->request->getPost('user_id'),
                'amount' =>  $amount,
                'profit' =>  $profit,
                'lost' => $lost,
                'total_sent' => $total_sent
            ]);

            $session = session();
            $session->setFlashdata('success', 'Envoi sauvegardé avec succès!');
            return redirect()->to('/operations');
        } 
    }

    // Show operation
    public function edit($operation_id)
    {
        $OperationModel = new OperationModel();
        $data['operation_data'] = $OperationModel->find($operation_id);
        $data['page_title'] = "Modification d'un envoi";
        return view('operation/edit', $data);
    }
    // update product data
    public function update($operation_id)
    {
        var_dump($operation_id);
        $OperationModel = new OperationModel();
        $data = [
            'user_id' => $this->request->getPost('user_id'),
            'profit'  => $this->request->getPost('profit'),
            'lost'  => $this->request->getPost('lost'),
            'amount'  => $this->request->getPost('amount'),
        ];
        $session = session();
        $session->setFlashdata('success', 'Envoi modifié');
        $save = $OperationModel->update($operation_id, $data);
        return redirect()->to('operation/index');
    }

    // Delete send
    public function delete($operation_id)
    {
        $db = \Config\Database::connect();
        $query = $db->query("DELETE FROM operations_table WHERE operations_table.operation_id = $operation_id");
        if ($query) {
            $session = session();
            $session->setFlashdata('success', 'Envoi supprimé!');
            return redirect()->to('/operations');
        };
    }
}
