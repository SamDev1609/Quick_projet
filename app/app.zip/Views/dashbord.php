<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
 <!-- top tiles -->
          <div class="row tile_count">
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Total Budget</span>
              <div class="count"><?= number_format($liq_total)?></div>
              <!-- <span class="count_bottom"><i class="green">4% </i> From last Week</span> -->
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-clock-o"></i> Solde Gabon</span>
              <div class="count"><?= number_format($liq_ga)?></div>
              <!-- <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>3% </i> From last Week</span> -->
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Solde Sénégal</span>
              <div class="count green"><?= number_format($liq_sn)?></div>
              <!-- <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span> -->
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Total revenu</span>
              <div class="count"><?= number_format($profittop)?></div>
              <!-- <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span> -->
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Total -> Gabon</span>
              <div class="count"><?= number_format($tg_data)?></div>
              <!-- <span class="count_bottom"><i class="red"><i class="fa fa-sort-desc"></i>12% </i> From last Week</span> -->
            </div>
            
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Total -> Sénégal</span>
              <div class="count"><?= number_format($ts_data)?></div>
              <!-- <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span> -->
            </div>
          </div>
          <!-- /top tago -->
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="dashboard_graph">
                      <!-- Graphique en ligne début-->
                <div class="col-md-9 col-sm-9 col-xs-12">
                   <div class="x_title">
                      <h2>Performance journalière</h2>
                      <ul class="nav navbar-right panel_toolbox">
                      </ul>
                      <div class="clearfix"></div>
                    </div>
                  <!-- <div id="chartjs_bar" class="demo-placeholder"></div> -->
                  <canvas id="chartjs_bar" width="1100" height="297"></canvas>
                </div>
                <!-- Graphique en ligne fin-->
                <div class="col-md-3 col-sm-3 col-xs-12 bg-white">
              <div class="x_panel">
                    <div class="x_title">
                      <h2>Derniers envois</h2>
                      <div class="clearfix"></div>
                    </div>
                    <div class="x_content">

                      <div class="">
                        <ul class="to_do">
                          <?php foreach ($operation_data as $data): ?>
                          <li class="bg-blue">
                            <p >
                          --> <span style="font-weight: bold;">N° envoi : <?= $data['operation_id']?></span>  | Vous avez transmis : <?= $data['amount']?> cfa & obtenu un profit de : <?= $data['profit']?> cfa
                              une perte de : <?= $data['lost']?> cfa, éffectué le <?= $data['created_at']?></p>
                          </li>
                          <?php endforeach; ?>
                        </ul>
                      </div>
                    </div>
                  </div>
            </div>

          </div>
          <br />

          <div class="row">


            <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="x_panel tile fixed_height_320">
                <div class="x_title">
                  <h2>Les derniers dépôts</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                 
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <div class="table-responsive  mt-1">
                                  <table class="table select-table">
                                    <thead>
                                      <tr>
                                        
                                       <th scope="col">N°</th>
								<th scope="col">Créateur</th>
								<th scope="col">Date</th>
								<th scope="col">Montant</th>
								<th scope="col">Bénéficiaire</th>
								<th scope="col">Téléphone</th>
                                      </tr>
                                    </thead>
                                    <tbody><?php foreach ($supply_data as $data): ?>
								<tr>
									<th scope="row"><?= $data['supply_id'] ?></th>
									<td><?= $data['surname'] ?></td>
									<td><?= $data['created_at'] ?></td>
									<td><?= $data['amount'] ?></td>
									<td><?= $data['name_receiver'] ?></td>
									<td><?= $data['tel_receiver'] ?></td>

								</tr>
                 <?php endforeach; ?>
                                    </tbody>
                                  </table>
                                </div>

                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="x_panel tile fixed_height_320 overflow_hidden">
                <div class="x_title">
                  <h2>Device Usage</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <canvas id="pie1Chart" style="width:100%;max-width:600px"></canvas>
                </div>
              </div>
            </div>


            <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="x_panel tile fixed_height_320">
                <div class="x_title">
                  <h2>Quick Settings</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <div class="dashboard-widget-content">
                    <canvas id="myChart"></canvas>

                    <div class="sidebar-widget">
                        <h4>Profile Completion</h4>
                        <canvas width="150" height="80" id="chart_gauge_01" class="" style="width: 160px; height: 100px;"></canvas>
                        <div class="goal-wrapper">
                          <span id="gauge-text" class="gauge-value pull-left">0</span>
                          <span class="gauge-value pull-left">%</span>
                          <span id="goal-text" class="goal-value pull-right">100%</span>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
<?= $this->endSection() ?>