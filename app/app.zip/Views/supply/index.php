<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<div class="col-md-12 col-sm-12 col-xs-12">
  <div class="x_panel">
    <div class="x_title">
      <button type="button" class="btn btn-success " data-toggle="modal" data-target="#exampleModal">+ Ajouter</button>
      <ul class="nav navbar-right panel_toolbox">
        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
        </li>

        <li><a class="close-link"><i class="fa fa-close"></i></a>
        </li>
      </ul>
      <div class="clearfix"></div>
    </div>
    <div class="x_content">
      <!-- <p class="text-muted font-13 m-b-30">
                      The Buttons extension for DataTables provides a common set of options, API methods and styling to display buttons on a page that will interact with a DataTable. The core library provides the based framework upon which plug-ins can built.
                    </p> -->
      <table id="datatable-buttons" class="table table-striped table-bordered">
        <thead>
          <tr>
           <th>N°</th>
                <th>CREATEUR & DATE</th>
                <th>MONTANT</th>
                <th>RECEVEUR</th>
                <th>TELEPHONE</th>
                <th>ACTION</th>
          </tr>
        </thead>
        <tbody><?php foreach ($supply_data as $data): ?>
                <tr>
                  <td><?= $data['supply_id'] ?></td>
                  <td><?= $data['surname'] ?> at <?= $data['created_at'] ?></td>
                  <td><?= $data['amount'] ?></td>
                  <td><?= $data['name_receiver'] ?></td>
                  <td><?= $data['tel_receiver'] ?></td>
                  <td>
                    <!-- <a href="/supply/show/<?= $data['supply_id'] ?>" class="btn btn-primary btn-sm">View</a> -->
                    <!-- <a href="/supply/edit/<?= $data['supply_id'] ?>" onclick="return confirm('Vous souhaitz modifier?')" class="btn btn-warning btn-sm">Edit</a> -->
                    <!-- <a href="/supply/delete/<?= $data['supply_id'] ?>" onclick="return confirm('Etes vous sure?')" class="btn btn-danger btn-sm">Delete</a> -->
                  </td>
                </tr>
              <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Opération connue</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="/supply/save" method="POST">

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Bénéficiaire <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="first-name" name="name_receiver" required="required" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Téléphone <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="last-name"  name="tel_receiver" required="required" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Montant</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="middle-name" class="form-control col-md-7 col-xs-12" type="text" name="amount">
                        </div>
                      </div>
                      <input type="hidden" name="user_id" value="<?= session()->id?>" class="form-control" id="recipient-name">
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <button class="btn btn-primary" data-dismiss="modal" type="button">Cancel</button>
						  <button class="btn btn-primary" type="reset">Reset</button>
                          <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                      </div>

                    </form>
      </div>
      
    </div>
  </div>
</div>


<?= $this->endSection() ?>