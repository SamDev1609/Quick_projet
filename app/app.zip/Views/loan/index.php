<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<div class="card">
  <div class="card-body">

    <button type="button" class="btn btn-success " data-toggle="modal" data-target="#exampleModal">+ Ajouter</button>
    <div class="row">
      <div class="col-12">
        <div class="table-responsive">
          <table id="order-listing" class="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>DATE DE PRET</th>
                <th>EMPREINTEUR</th>
                <th>MONTANT</th>
                <th>PAYS</th>
                <th>STATUS</th>
                <th>ACTION</th>
              </tr>
            </thead>
            <tbody><?php foreach ($loan_data as $data): ?>
                <tr>
                  <td><?= $data['loan_id'] ?></td>
                  <td><?= $data['created_at'] ?></td>
                  <td><?= $data['surname'] ?></td>
                  <td><?= $data['amount'] ?></td>
                  <td><?= $data['code_country'] ?></td>
                  <td><?= $data['status'] ?></td>
                  <td>
                    <!-- <a href="/operations/show/<?= $data['loan_id'] ?>" class="btn btn-primary btn-sm">View</a> -->
                    <?php if ($data['status'] !== 'remboursée') { ?>

                      <a href="/loan/edit/<?= $data['loan_id'] ?>" onclick="return confirm('Souhaitez-vous faire une avance à ce prêt?')" class="btn btn-warning btn-sm">Faire une avance</a>
                      <a href="/loan/buy_loan/<?= $data['loan_id'] ?>" onclick="return confirm('Souhaitez-vous payer cette dette?')" class="btn btn-success btn-sm" type="submit">Tout payer</a>
                      <!-- <a href="/loan/delete/<?= $data['loan_id'] ?>" onclick="return confirm('Etes vous sure?')" class="btn btn-danger btn-sm">Delete</a> -->
                    <?php } ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ModalLabel">Faites-en un nouveau prêt</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="/loan/save" method="POST">
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Pays :</label>
            <select name="code_country" required class="form-select form-control form-control-default">
              <option value="">Choisir un pays</option>
              <option value="Gabon">Gabon</option>
              <option value="Senegal">Sénégal</option>

            </select>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Montant :</label>
            <input type="text" name="amount" class="form-control" id="recipient-name">
          </div>

      </div>
      <input type="hidden" name="user_id" value="<?= session()->id ?>" class="form-control">
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">+ Ajputer</button>
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
      </div>
      </form>
    </div>
  </div>
</div>
<?= $this->endSection() ?>