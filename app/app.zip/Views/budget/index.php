<?= $this->extend('layout')?>
<?= $this->section('content')?><br><br><br><br><br><br><br><br>
<div class="card">
  <div class="card-body">
  GESTION DES BUDGETS
    <div class="row">
      <div class="col-12">
        <div class="table-responsive">
          <table id="order-listing" class="table">
            <thead>
              <tr>
                <th>CODE BUDGET</th>
                <th>CCREATEUR & DATE</th>
                <th>GABON</th>
                <th>SENEGAL</th>
                <th>ACTION</th>
              </tr>
            </thead>
            <tbody><?php foreach ($budget_data as $data): ?>
                <tr>
                  <td><?= $data['budget_id'] ?></td>
                  <td><?= $data['surname'] ?> at <?= $data['created_at'] ?></td>
                  <td><?= $data['budget_ga'] ?></td>
                  <td><?= $data['budget_sn'] ?></td>
                  <td>
                    <!-- <a href="/budget/show/<?= $data['budget_id'] ?>" class="btn btn-primary btn-sm">View</a> -->
                    <a href="/budget/edit/<?= $data['budget_id'] ?>" onclick="return confirm('Souhaitez-vous mettre à jour le budget?')" class="btn btn-warning btn-sm">Mettre à jour</a>
                    <!-- <a href="/budget/delete/<?= $data['budget_id'] ?>" onclick="return confirm('Etes vous sure?')" class="btn btn-danger btn-sm">Delete</a> -->
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>